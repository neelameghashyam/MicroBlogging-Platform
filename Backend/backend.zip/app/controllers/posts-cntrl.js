import Post from "../models/post-model.js";
import multer from 'multer';

const postCntrl = {};

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, "uploads/post-uploads");
    },
    filename: (req, file, cb) => {
      cb(null, file.originalname);
    }
});


const upload = multer({ storage }).single('file');


postCntrl.create = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    const body = req.body;
    try {
      const post = new Post(body);
      post.user = req.userID;
      if (req.file) {
        post.file = {
          path: req.file.path,
          contentType: req.file.mimetype
        };
      }
      await post.save();
      res.status(201).json(post);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
}

postCntrl.edit =async (req,res)=>{
    const { id } = req.params

    let post 
    if(req.role=='admin'||req.role=='moderator'){
          post=await Post.findById(id)
    }else{
      post=await Post.findOne({_id:id,user:req.userID})
    }
    if(post){
    upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    const body = req.body;
  
    try {
      post.body = body.body || post.body
      post.keywords = body.keywords || post.keywords
  
      if (req.file) {
        post.file = {
          path: req.file.path,
          contentType: req.file.mimetype
        }
      }
      await post.save();
      res.status(200).json(post);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
})
}
else {
    res.status(404).json({ error: "Post not found or you are not authorized to edit it" });
  }
}

postCntrl.deletePost= async(req,res)=>{
  const { id } = req.params
  try{
    let post
    if(req.role=="admin"|| req.role=="moderator"){
      post = await Post.findByIdAndDelete(id)
    }else{
      post = await Post.findOneAndDelete({_id:id,user:req.userID})
    }
    if(!post){
      res.status(404).json({})
    }
    res.json(post)
  }catch (err) {
      res.status(500).json({ error: err.message });
    }
}


postCntrl.likes = async(req,res)=>{
    const {id}=req.params
    try{
       const post= await Post.findOne({_id:id})
       if(post){
        if( !post.likes.includes(req.userID)){
            await post.updateOne({$push:{likes:req.userID}})
            res.status(200).json("liked sucessfully")
        }
        else{
            await post.updateOne({$pull:{likes:req.userID}})
            res.status(200).json("disliked sucessfully")
        }
       }
    }catch(err){
        res.status(500).json({ error: err.message });
    }
}

postCntrl.getPostsOfUser= async(req,res)=>{
  const {id}=req.params
  try{
    const posts=await Post.find({user:id})
    if(posts){
      res.status(200).json(posts)
    }
    else{
      res.status(404).json("no posts found")
    }

  }catch(err){
    res.status(500).json({ error: err.message })
  }
}

postCntrl.comment=async (req,res)=>{
  const {id}=req.params
  const {title,body}=req.body
  try{
    const post = await Post.findById({_id:id})
    if(post){
      const commentData={
        title:title,
        body:body,
        user:req.userID
      }
      await post.updateOne({$push:{comments:commentData}})
      res.status(200).json("commented sucessfully")
    }
  }catch(err){
    res.status(500).json({ error: err.message });
   }
}

postCntrl.deleteComment = async (req, res) => {
  const { id } = req.params // Comment ID
  const { postId } = req.body // Post ID

  try {
    const post = await Post.findByIdAndUpdate(postId,{ $pull: { comments: { _id: id } } },{ new: true })
    if (!post) {
      return res.status(404).json({ error: 'Post not found' })
    }
    res.status(200).json({ message: 'Comment removed successfully' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}



export default postCntrl;
