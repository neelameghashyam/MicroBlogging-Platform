import Profile from "../models/profile-model.js";
import multer from 'multer';

const profileCntrl = {};

// Set up multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/profile-uploads");
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage }).single('profilePic')

profileCntrl.create = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ error: err.message })
    }
    const body = req.body
    try {
      const pro_exist = await Profile.findOne({ user: req.userID })
      if (pro_exist) {
        return res.status(400).json({ error: "User has already created a profile" })
      }
      const profile = new Profile(body)
      profile.user = req.userID

      if (req.file) {
        profile.profilePic = {
          path: req.file.path,
          contentType: req.file.mimetype
        }
      }

      await profile.save()
      res.status(201).json(profile)
    } catch (err) {
      res.status(500).json({ error: err.message })
    }
  })
};


profileCntrl.edit = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ error: err.message })
    }
  
    const userID = req.userID;
    const body = req.body;
  
    try {
      const profile = await Profile.findOne({ user: userID });
  
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      profile.userName = body.userName || profile.userName;
      profile.bio = body.bio || profile.bio;
  
      if (req.file) {
        profile.profilePic = {
          path: req.file.path,
          contentType: req.file.mimetype
        };
      }
      await profile.save();
      res.status(200).json(profile);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
};

profileCntrl.getUser = async (req, res) => {
  // we use user id 
  const { id } = req.params
  try {
    const user = await Profile.findOne({user:id})

    if (user) {
      res.status(200).json(user)
    } else {
      res.status(404).json({ error: "Profile not found" })
    }
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

profileCntrl.follow = async (req, res) => {
 const { id } = req.params
 if(id !== req.userID){
 try{
  const userToFollow=await Profile.findOne({user:id})
  const currentUser=await Profile.findOne({user:req.userID})
  if(!userToFollow.followers.includes(req.userID)){
    await userToFollow.updateOne({ $push: { followers: req.userID } });
    await currentUser.updateOne({ $push: { following: id } })
    res.status(200).json("followed sucessfully")
  }
 }catch(err){
  res.status(500).json({ error: err.message });
 }
}else{
  res.status(404).json("You can't follow yourself")
}
}

profileCntrl.unfollow= async (req,res)=>{
  const { id } = req.params
  if(id !== req.userID){
  try{
   const userToFollow=await Profile.findOne({user:id})
   const currentUser=await Profile.findOne({user:req.userID})
   if(userToFollow.followers.includes(req.userID)){
     await userToFollow.updateOne({ $pull: { followers: req.userID } });
     await currentUser.updateOne({ $pull: { following: id } })
     res.status(200).json("unfollowed sucessfully")
   }
  }catch(err){
   res.status(500).json({ error: err.message });
  }
 }else{
   res.status(404).json("You can't unfollow yourself")
 }
}

profileCntrl.Allprofiles= async (req,res)=>{
  try{
   const profiles= await Profile.find()
   const mainProfiles= await profiles.filter(e=>{
       if(e.user != req.userID){
        return e
       }
   })
  
   res.status(200).json(mainProfiles)
  }catch(err){
    res.status(500).json({ error: err.message })
  }
}


export default profileCntrl;
