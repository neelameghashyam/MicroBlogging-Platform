import { model, Schema } from "mongoose";

const commentsSchema= new Schema({
  title:String,
  body:String,
  user:Schema.Types.ObjectId
},{ timestamps: true })

const postSchema = new Schema({
  title:String,
  user:Schema.Types.ObjectId,
  body: String,
  keywords: String,
  file:{
    data:Buffer,
    contentType: String
  },
  comments:[commentsSchema],
  likes:Array
}, { timestamps: true })

const Post = model("Post", postSchema)

export default Post
