import { Routes, Route, Link } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useContext } from 'react';
import PrivateRoute from './components/PrivateRoute';
import AuthContext from './context/AuthContext';
import Register from './pages/Register';
import Login from './pages/Login';
import Profile from './pages/Profile'
import ResetPassword from './pages/ResetPassword'
import ProfileCreation from './pages/ProfileCreation';
import PostCreation from './pages/PostCreation';
import Dashboard from './pages/Dashboard';
import ListUsers from './pages/ListUsers';
import Forbidden from './pages/Forbidden';
import AuthorizRoute from './components/AuthorizeRoute';
import "../App.css"
import AllProfiles from './pages/AllProfiles';

function App() {
    const { state, handleLogout } = useContext(AuthContext);

    return (
        <div className="App">
            <h2>User Mini Blog App</h2>
            <ul>
                {state.isLoggedIn ? (
                    <>
                
                        <li className='li'><Link to="/profile">Profile</Link></li>
                        <li className='li'><Link to="/post-creation">Post Creation</Link></li>
                        {(state.user.role==='admin' || state.user.role==='moderator')&&<li className='li'><Link 
                             to="/listUsers">List-Users</Link></li> }
                        <li className='li'><Link to="/allProfiles">AllProfiles</Link></li>
                        <li className='li'><Link to="/dashboard">Dashboard</Link></li>
                        <li className='li'><Link to="/resetPassword">ResetPassword</Link></li>
                        <li className='li'><button onClick={handleLogout}>Logout</button></li>
                    </>
                ) : (
                    <>
                        <li className='li'><Link to="/register">Register</Link></li>
                        <li className='li'><Link to="/login">Login</Link></li>
                    </>
                )}
            </ul>

            <Routes>
                <Route path="/register" element={<Register />} />
                <Route path="/login" element={<Login />} />
                <Route path="/profile-creation" element={
                    <PrivateRoute>
                        <ProfileCreation />
                    </PrivateRoute>
                } />
                <Route path="/post-creation" element={
                    <PrivateRoute>
                        <PostCreation />
                    </PrivateRoute>
                } />
                <Route path="/dashboard" element={
                    <PrivateRoute>
                        <Dashboard />
                    </PrivateRoute>
                } />
                <Route path="/profile" element={
                    <PrivateRoute>
                        <Profile />
                    </PrivateRoute>
                } />
                <Route path="/resetPassword" element={
                    <PrivateRoute>
                        <ResetPassword />
                    </PrivateRoute>
                } />
                <Route path='/listUsers' element={
                    <PrivateRoute>
                        <AuthorizRoute permittedRoles={['admin','moderator']}>
                              <ListUsers/>
                        </AuthorizRoute>
                    </PrivateRoute>
                }/>
                <Route path='/allProfiles' element={
                    <PrivateRoute>
                        <AllProfiles/>
                    </PrivateRoute>
                }/>
                <Route path='/forbidden' element={<Forbidden/>}/>
            </Routes>

            <ToastContainer />
        </div>
    );
}

export default App;
