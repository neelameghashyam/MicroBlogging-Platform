import { useState,useContext,useEffect } from "react";
import AuthContext from "../context/AuthContext";
import axios from "../config/axios";
export default function AllProfiles(){
const [profiles,setProflies]=useState([])
const [currentProfile, setCurrentProfile] = useState({ following: [] });
const {state}=useContext(AuthContext)

useEffect(()=>{
    (async()=>{
        try{
           const response= await axios.get('/api/profiles',{
               headers: { 'Authorization': localStorage.getItem('token') }})
               setProflies(response.data)
        }catch(err){
           console.log(err)
        }
       })()
},[])
useEffect(() => {
    if (state.user) {
      const fetchProfile = async () => {
        try {
          const profile = await axios.get(`/api/profile/get/${state.user._id}`, {
            headers: { 'Authorization': localStorage.getItem('token') },
          });
          await setCurrentProfile(profile.data)
        //   console.log(currentProfile)
        } catch (err) {
          console.error('Error fetching user data:', err)
        }
      }

      fetchProfile()
    }
  }, [state.user])

  const handleFollow = async (id) => {
    try {
      await axios.put(`/api/profile/follow/${id}`,{headers: { 'Authorization': localStorage.getItem('token')}})
    } catch (err) {
      console.error('Error following user:', err);
    }
  }
  


if (!state.user) {
    return <p>Loading...</p>;
  }

return(
    <div>
        <ul>
        {profiles.map(ele=>{
            return <li key={ele._id}>{ele.userName}{
                currentProfile.following && currentProfile.following.includes(ele._id)
                 ? <button>unfollow</button>
                 : <button onClick={() => handleFollow(ele.user)}>follow</button>}</li>
        })}
        </ul>
    </div>
)

}