import { useContext, useEffect, useState } from 'react';
import AuthContext from '../context/AuthContext';
import axios from '../config/axios';

export default function Dashboard() {
    const { state } = useContext(AuthContext);
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPosts = async () => {
            if (!state.user) {
                setLoading(true);
                return;
            }

            try {
                const response = await axios.get(`/api/post/get-posts/${state.user._id}`, {
                    headers: { 'Authorization': localStorage.getItem('token') }
                });
                setPosts(response.data);
            } catch (err) {
                console.error('Error fetching posts:', err);
            } finally {
                setLoading(false);
            }
        };

        fetchPosts();
    }, [state.user]);

    if (loading) {
        return <p>Loading...</p>;
    }
   
    return (
        <div>
            <h2>Welcome, {state.user.username}</h2>
            {posts.map(post => (
                <div key={post._id}>
                    <p>Title: {post.title}</p>
                    <p>Body: {post.body}</p>
                    <p>Keywords: {post.keywords}</p>
                    <p>Likes: {post.likes.length} | Comments: {post.comments.length}</p>
                </div>
            ))}
        </div>
    );
}
