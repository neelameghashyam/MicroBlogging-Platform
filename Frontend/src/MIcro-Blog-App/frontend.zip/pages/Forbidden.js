export default function Forbidden(){
    return (<div>
        <h2>You don't have access</h2>
    </div>)
}