import { useEffect,useState,useContext } from "react";
import axios from "../config/axios"
import AuthContext from "../context/AuthContext";
export default function ListUsers(){
const [users,setUsers]=useState([])
const {state}=useContext(AuthContext)

    useEffect(()=>{
        (async()=>{
         try{
            const response= await axios.get('/api/user/list',{
                headers: { 'Authorization': localStorage.getItem('token') }})
                setUsers(response.data)
         }catch(err){
            console.log(err)
         }
        })()
    },[])
   
     const handleChangeRole=async(id,role)=>{
           try{
            const response =await axios.put(`/api/user/role/${id}`,{role:role},
                {headers: { 'Authorization': localStorage.getItem('token') }}
            )
            const newArr=users.map(ele=>{
                if(ele._id == response.data._id){
                    return response.data
                }else{
                    return ele
                }
            })
            setUsers(newArr)
           }catch(err){
            console.log(err)
           }
     }


    return(
        <div>
        <h2>Listing Users -{users.length} </h2>
        <ul>            
           {users.map((e)=>{
              return<li key={e._id}>{e.email}-{e.role}
              {state.user.role === 'admin' && state.user._id !== e._id &&
              <>
              <select
                  value={e.role}
                  onChange={(ele) => handleChangeRole(e._id, ele.target.value)}
                  >
                    <option value=''>select</option>
                        {['admin', 'moderator', 'user'].map((role, i) => (
                          <option value={role} key={i}>{role}</option>
                        ))}
                </select>
                <button>remove</button>
              </>
           }
              </li>
            })}
        </ul>
        </div>
    )
}