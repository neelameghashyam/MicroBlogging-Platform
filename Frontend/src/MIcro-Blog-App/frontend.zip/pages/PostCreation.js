
import { useState,useContext } from 'react';
import AuthContext from '../context/AuthContext';


export default function PostCreation() {
    const [body, setBody] = useState('');
    const [title, setTitle] = useState('');
    const [file, setFile] = useState(null);
    const{handlePostCreation}=useContext(AuthContext)

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData ={
            title:title,
            body:body,
            file:file
        }

       await handlePostCreation(formData)
       setBody("")
       setTitle("")
       setFile(null)
    };

    return (
        <div>
            <h2>Create a Post</h2>
            <form onSubmit={handleSubmit}>
                <label>Title</label><br/>
                <input type='Text' 
                value={title}
                onChange={(e) => setTitle(e.target.value)} 
                /><br/>
                <label>Body</label><br/>
                <textarea 
                    value={body} 
                    onChange={(e) => setBody(e.target.value)} 
                    placeholder="What's on your mind?" 
                    required 
                /><br/>
                <label>Image/Video</label><br/>
                <input 
                    type="file" 
                    onChange={(e) => setFile(e.target.files[0])} 
                /><br/>
                <button type="submit">Post</button>
            </form>
        </div>
    );
}
