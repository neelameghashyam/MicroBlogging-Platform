import { useContext, useEffect } from "react";
import AuthContext from "../context/AuthContext";
import axios from "../config/axios";

export default function Profile() {
  const { state, profileState, dispatchProfile } = useContext(AuthContext);

  useEffect(() => {
    if (state.user && state.user._id) {
      const fetchProfile = async () => {
        try {
          const profile = await axios.get(`/api/profile/get/${state.user._id}`, {
            headers: { 'Authorization': localStorage.getItem('token') },
          });
          dispatchProfile({ type: "GET", payload: profile.data });
        } catch (err) {
          console.error('Error fetching user data:', err);
        }
      };

      fetchProfile();
    }
  }, [state.user, dispatchProfile]);

  if (!state.user) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      <h2>Profile</h2>
      {profileState.map((e, index) => (
        <div key={index}>
          <h3>User Name : {e.userName}</h3>
          <h3>Role: {state.user.role}</h3>
          <h3>Bio : {e.bio}</h3>
          
            <img
              src={`/uploads/profile-uploads`} // Correct path to the profile picture
              alt="Profile"
            />
         
        </div>
      ))}
    </div>
  );
}
